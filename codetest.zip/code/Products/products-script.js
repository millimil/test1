const products = {
    Minecraft: [
        { name: "€0", image: "../website-assets/images/MCLOGO.webp", description: "300MB RAM, 2GB SSD." },
        { name: "€0,85", image: "../website-assets/images/MCLOGO.webp", description: "800MB RAM, 5GB SSD" },
        { name: "€2,00", image: "../website-assets/images/MCLOGO.webp", description: "2,5GB RAM, 7,5GB SSD" },
        { name: "€4,50", image: "../website-assets/images/MCLOGO.webp", description: "4GB RAM, 10GB SSD" },
    ],
    FiveM: [
        { name: "€0", image: "../website-assets/images/GTAVlogo.png", description: "450MB, 0,25 cores, 5GB SSD" },
        { name: "€1,00", image: "../website-assets/images/GTAVlogo.png", description: "850MB, 0,5 cores, 10GB SSD" },
        { name: "€2,00", image: "../website-assets/images/GTAVlogo.png", description: "2GB, 1 core, 20GB SSD" },
        { name: "€4,00", image: "../website-assets/images/GTAVlogo.png", description: "4GB, 1,5 cores, 40GB SSD" },
    ]
};

function filterProducts(type) {
    const grid = document.getElementById("productGrid");
    const buttons = document.querySelectorAll(".selector button");

    // Clear active class from buttons
    buttons.forEach(button => button.classList.remove("active"));

    // Set active button
    buttons.forEach(button => {
        if (button.textContent.toLowerCase() === type) {
            button.classList.add("active");
        }
    });

    // Clear current products
    grid.innerHTML = "";

    // Add new products
    products[type].forEach(product => {
        const card = document.createElement("div");
        card.className = "product-card";
        card.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>${product.description}</p>
            <button onclick="alert('You clicked ${product.name}!')">Buy Now</button>
        `;
        grid.appendChild(card);
    });
}

// Load default category
filterProducts("hosting");
